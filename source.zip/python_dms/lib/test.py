from scipy.sparse import diags
import numpy as np
import scipy as scp
from scipy.sparse import diags
import scipy.sparse.linalg as spl
import scipy as scp
from scipy.sparse import hstack
from scipy.sparse import vstack
# from scipy.sparse import csr_matrix
from scipy.sparse import csc_matrix
import matplotlib.pyplot as plt
from scipy.sparse import identity
from PIL import Image
import cv2
import time
from scipy.sparse.linalg import spsolve
np.set_printoptions(threshold=np.inf)
np.set_printoptions(linewidth=np.inf)
from scipy.sparse.linalg import LinearOperator
from scipy.sparse.linalg import *
import cupy as cp

image = cv2.imread('../../examples/10081.jpg', cv2.IMREAD_COLOR)
image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY) 


beta= 5
lam = 0.01
dk = 1.01*beta*2
eps=0.02

def optDV(rows,cols):
    diagonals = [
        (0.5 * np.ones( cols - 1)).tolist(),
        (-0.5 * np.ones( cols)).tolist(),
        [0.5],
    ]
    block = diags(diagonals, [1, 0, - cols + 1])
    opt_V = scp.sparse.block_diag([block for _ in range( rows)])
    return opt_V

def optDH(rows,cols):
    diagonals = [
        -0.5 * np.ones(  rows *   cols),
        0.5 * np.ones((  rows - 1) *   cols),
        0.5 * np.ones(  cols),
    ]

    optDH = diags(diagonals, [0,   cols, -(  rows *   cols) +   cols])
    return optDH

def optD(x):
    y = np.zeros(( rows,  cols, 2))
    y[:, :, 0] = (np.concatenate((x[1:, :] - x[0:-1, :], np.zeros((1,  cols))), axis=0)/ 2.0)
    y[:, :, 1] = (np.concatenate((x[:, 1:] - x[:, 0:-1], np.zeros(( rows, 1))), axis=1)/ 2.0)
    return y

def optD1(rows,cols):
    D1 = hstack((optDV(rows,  cols), -optDH(rows, cols)))
    return D1

def mv(e):
    C1 = 1 + ( lam / (2 *  eps * dk))
    C2 = 2 *  lam *  eps / dk
    hat = 2 *  beta / dk*  optD(un_SLPAM) ** 2
    hat0 = hat[:, :, 0].ravel("C")
    hat1 = hat[:, :, 1].ravel("C")
    hat_concatenate = np.hstack((hat0, hat1))
    block1 = hat_concatenate*e
    block2 = e*C1
    block3 = C2 * D1adj(D1e(e))
    res = block1 + block2 + block3
    return res

def D1e(e):
    res = np.zeros(rows*cols)
    for i in range(rows*cols):
        # print(cols*(i//cols)+(i+1)%cols,i,i+rows*cols,rows*cols+(i+cols)%(rows*cols))        
        res[i] = e[cols*(i//cols)+(i+1)%cols]-e[i] + e[i+rows*cols] - e[rows*cols+(i+cols)%(rows*cols)]
    return res/2.

def D1adj(y):
    res = np.zeros(rows*cols*2)
    for i in range(rows*cols):
        res[i] =  y[cols*(i//cols)+(i+2)%cols] -y[i%(rows*cols)]
        # print(cols*(i//cols)+(i+cols-1)%cols,i%(rows*cols))

    for j in range(rows*cols,rows*cols*2):
        res[i] =  y[j%(rows*cols)]-y[(j+rows*cols-cols)%(rows*cols)]
        # print(j%(rows*cols),(j+rows*cols-cols)%(rows*cols))
    return res/2.

size = 200
np.random.seed(1)
image_np = np.asarray(image, dtype="int32" )[100:100+size,100:100+size]
un_SLPAM = (image_np + 0.1*255*np.random.normal(0,1,size=image_np.shape))/255.
rows,cols = np.shape(un_SLPAM)
e=np.random.normal(0,1,size=(rows,cols,2))

x_gpu = cp.array([1, 2, 3])
# right_term = (e+ 2 *  beta / dk*  optD( un_SLPAM) ** 2 )
# e_ravel_0 = right_term[:, :, 0].ravel("C")
# e_ravel_1 = right_term[:, :, 1].ravel("C")
# e_ravel = np.hstack((e_ravel_0, e_ravel_1)).reshape((rows*cols*2,1))
# A = LinearOperator((rows*cols*2,rows*cols*2), matvec=mv)
# time_start = time.time()
# temp1,info = lgmres(A,e_ravel, tol=1e-5)
# print('linear op--',time.time()-time_start)

# C1 = 1 + ( lam / (2 *  eps * dk))
# C2 = 2 *  lam *  eps / dk
# hat = 2 *  beta / dk*  optD( un_SLPAM) ** 2
# hat0 = hat[:, :, 0].ravel("C")
# hat1 = hat[:, :, 1].ravel("C")
# hat_concatenate = np.hstack((hat0, hat1))
# block1 = csc_matrix(diags([hat_concatenate.tolist()], [0]))
# block2 = csc_matrix(identity( rows* cols * 2) * C1)
# block3 = C2 * csc_matrix( optD1(rows,  cols).T.dot( optD1(rows,  cols)))
# mat = block1 + block2 + block3 
# time_start = time.time()
# temp2,info = lgmres(mat,e_ravel)
# print('old --',time.time()-time_start)

# time_start = time.time()
# temp3 = spsolve(mat,e_ravel)
# print('old old --',time.time()-time_start)

# print(temp1[0]-temp2[0])
# print(temp2[0]-temp3[0])
# print(temp1[0]-temp3[0])
# # e[:, :, 0] = temp[:  rows* cols].reshape( rows,  cols)
# # e[:, :, 1] = temp[ rows* cols:].reshape(  rows,  cols)

