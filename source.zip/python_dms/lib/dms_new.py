# -*- coding: utf-8 -*-
import numpy as np
from scipy import fftpack
from scipy.sparse import diags
import scipy as scp
from scipy.sparse import hstack
from scipy.sparse import vstack
from scipy.sparse import identity
from scipy.sparse.linalg import spsolve
import time
from tools_dms import *
# from alive_progress import alive_bar
from scipy.sparse.linalg import lgmres
from scipy.sparse.linalg import LinearOperator
import math

class DMS_new:
    def __init__(self,clean=None,noised_image_input=None,e_init=None,
                    norm_type="l1",
                    edges="similar",
                    beta=8,lamb=1e-2,
                    eps=0.2,eps_AT_min=0.02,
                    stop_criterion=1e-4,MaximumIteration=5000,
                    method="SLPAM",
                    dkSLPAM_factor=1e-4,
                    A=None):
                
        self.eps = eps
        self.eps_AT_min = eps_AT_min
        self.MaximumIteration = MaximumIteration
        self.stop_criterion = stop_criterion
        self.method = method
        self.beta = beta
        self.lam = lamb
        self.norm_type = norm_type
        self.dkSLPAM_factor = dkSLPAM_factor
        self.edges = edges
        self.norms = CreateNorms()
        self.prox = ProximityOperators(self.eps)

        # Image variable
        self.clean= clean
        self.noised_image_input = noised_image_input
        self.A = A
        shape = np.shape(noised_image_input)
        size = np.size(shape)
        if size == 2:
            self.rows, self.cols = noised_image_input.shape
            self.canal = 1
            if np.max(noised_image_input) > 100:
                print('Convert image to float \n')
                self.noised_image_input = (np.copy(noised_image_input)) / 255.0
            else:
                print('Image in float')
                self.noised_image_input = np.copy(noised_image_input)
            self.en_SLPAM = np.zeros((self.rows,self.cols,2))
            self.en_PALM = np.zeros((self.rows,self.cols,2))
            self.un_SLPAM = self.noised_image_input
            self.un_PALM = self.noised_image_input
        elif size == 3:
            self.rows, self.cols, self.canal = noised_image_input.shape
            if np.max(noised_image_input) > 100:
                self.noised_image_input = (np.copy(noised_image_input)) / 255.0
            else:
                self.noised_image_input = np.copy(noised_image_input)
            self.canal = 3
            self.un_SLPAM = self.noised_image_input
            self.un_PALM = self.noised_image_input
            if edges == 'similar': # all channels RGB have the same contour
                self.en_SLPAM = np.zeros((self.rows,self.cols,2))
                self.en_PALM = np.zeros((self.rows,self.cols,2))
            elif edges == 'distinct':
                self.en_SLPAM = np.zeros((self.rows,self.cols,2, self.canal))
                self.en_PALM = np.zeros((self.rows,self.cols,2, self.canal))

        # SL-PAM parameters
        self.Jn_SLPAM = None

        # PALM parameter    
        self.Jn_PALM = None
        kernel2 = np.array([[1], [-1]])
        kernel1 = np.array([[1, -1]])
        self.v = psf2otf(kernel2, (self.rows, self.cols))
        self.h = psf2otf(kernel1, (self.rows, self.cols))

    def Atx(self, x):
        if self.canal==1:
            img_ft = fftpack.fft2(x, axes=(0, 1))
            img_ft2 = np.conj(self.A) * img_ft
            self.Aadjoint = np.real(fftpack.ifft2(img_ft2, axes=(0, 1)))
            return self.Aadjoint
        elif self.canal==3:
            output= np.zeros_like(x)
            for i in range(3):
                img_ft = fftpack.fft2(x[:,:,i], axes=(0, 1))
                img_ft2 = np.conj(self.A) * img_ft
                output[:,:,i]= np.real(fftpack.ifft2(img_ft2, axes=(0, 1)))
            return output
    def Ax(self, x):
        if self.canal==1:
            img_ft2 = self.A * fftpack.fft2(x, axes=(0, 1))
            Ax = np.real(fftpack.ifft2(img_ft2, axes=(0, 1)))
            Ax = Ax
            return Ax
        elif self.canal==3:
            output= np.zeros_like(x)
            for i in range(3):
                img_ft2 = self.A * fftpack.fft2(x[:,:,i], axes=(0, 1))
                output[:,:,i] = np.real(fftpack.ifft2(img_ft2, axes=(0, 1)))
            return output

    def data_fidelity(self, u, z):
        return 0.5 * (self.norms.L2(self.Ax(u) - z)) ** 2

    def data_fidelity_prox(self, x, tau, z):
        return self.prox.L2_restoration(x, tau, z, self.A.astype("complex128"),self.canal)

    def coupling_term(self, u, e):
        if self.canal == 3:
            if self.edges=='similar':
                return self.beta*np.sum((np.repeat(((1 - e))[:, :, :, np.newaxis], self.canal, axis=3)* self.optD(u)) ** 2)
            elif self.edges =='distinct':
                pass
        elif self.canal == 1:
            return self.beta*np.sum(((1 - e) * self.optD(u)) ** 2)

    def coupling_term_du(self, u, e):
        if self.canal == 3:
            if self.edges=='similar':
                return 2 * self.beta*self.optDadjoint((np.repeat(((1 - e))[:, :, :, np.newaxis], self.canal, axis=3)** 2* self.optD(u)) )
        elif self.canal == 1:
            return 2 * self.beta*self.optDadjoint(self.optD(u)*(1 - e) ** 2)

    def coupling_term_de(self, u, e):
        if self.canal == 3:
            if self.edges=='similar':
                 return -2 * (1 - e) *self.beta* self.S_D(u)
        elif self.canal == 1:
            return -2 * (1 - e) *self.beta* self.S_D(u)


       
    def S_D(self, u):
        if self.canal == 3:
            temp = np.sum(self.optD(u) ** 2, 3)
            return temp
        elif self.canal == 1:
            temp = self.optD(u) ** 2
            return temp
    
    def mv(self,e):
        C1 = 1 + ( self.lam / (2 *  self.eps * self.dk))
        C2 = 2 *  self.lam *  self.eps / self.dk
        hat = 2 *  self.beta / self.dk*  self.optD(self.un_SLPAM) ** 2
        hat0 = hat[:, :, 0].ravel("C")
        hat1 = hat[:, :, 1].ravel("C")
        hat_concatenate = np.hstack((hat0, hat1))
        block1 = hat_concatenate*e
        block2 = e*C1
        block3 = C2 * self.D1adj(self.D1e(e))
        res = block1 + block2 + block3
        return res

    def D1e(self,e):
        res = np.zeros(self.rows*self.cols)
        for i in range(self.rows*self.cols):
            res[i] = e[self.cols*(i//self.cols)+(i+1)%self.cols]-e[i] + e[i+self.rows*self.cols] - e[self.rows*self.cols+(i+self.cols)%(self.rows*self.cols)]
        return res/2.

    def D1adj(self,y):
        res = np.zeros(self.rows*self.cols*2)
        for i in range(self.rows*self.cols):
            res[i] =  y[self.cols*(i//self.cols)+(i+2)%self.cols] -y[i%(self.rows*self.cols)]
        for j in range(self.rows*self.cols,self.rows*self.cols*2):
            res[i] =  y[j%(self.rows*self.cols)]-y[(j+self.rows*self.cols-self.cols)%(self.rows*self.cols)]
        return res/2.

    # contour length penalization
    def R_term(self, e):
        if self.norm_type == "l0":
            return self.norms.L0(e)
        elif self.norm_type == "l1":
            return self.norms.L1(e)
        elif self.norm_type == "AT":
            e_ravel_0 = e[:, :, 0].ravel("C")
            e_ravel_1 = e[:, :, 1].ravel("C")
            e_ravel = np.hstack((e_ravel_0, e_ravel_1))
            optD1e = self.optD1().dot(e_ravel)
            return self.norms.AT(optD1e=optD1e, e=e, eps=self.eps)
        elif self.norm_type == "l1l2":
            return self.gamma_1 * self.norms.L1(e) + self.gamma_2 * self.norms.L2D(e)
    def R_prox(self, e, tau=None,ck=None,dk=None):
        if self.norm_type == "l0":
            return self.prox.L0(e, tau)
        elif self.norm_type == "l1":
            return self.prox.L1(e, tau)
        elif self.norm_type == "AT" and (self.method=='SLPAM' or self.method=='SLPAM_AT_eps_descent'):
            rhs = (self.en_SLPAM+ 2 * self.beta / self.dk * self.optD(self.un_SLPAM) ** 2)
            e_ravel_0 = rhs[:, :, 0].ravel("C")
            e_ravel_1 = rhs[:, :, 1].ravel("C")
            e_ravel = np.hstack((e_ravel_0, e_ravel_1))
            C1 = 1 + (self.lam / (2 * self.eps * self.dk))
            C2 = 2 * self.lam * self.eps / self.dk
            hat = 2 * self.beta / self.dk * self.optD(self.un_SLPAM) ** 2
            hat0 = hat[:, :, 0].ravel("C")
            hat1 = hat[:, :, 1].ravel("C")
            hat_conca = np.hstack((hat0, hat1))
            block1 = csc_matrix(diags([hat_conca.tolist()], [0]))
            block2 = csc_matrix(identity(self.rows*self.cols * 2) * C1)
            block3 = C2 * csc_matrix(self.optD1().T.dot(self.optD1()))
            mat = block1 + block2 + block3
            temp = spsolve(mat, e_ravel)
            # rhs[:, :, 0] = temp[: self.rowscols].reshape(self.rows, self.cols)
            # rhs[:, :, 1] = temp[self.rowscols :].reshape(self.rows, self.cols)
            # right_term = (e+ 2 * self.beta / dk* self.optD(self.un_SLPAM) ** 2 )
            # e_ravel_0 = right_term[:, :, 0].ravel("C")
            # e_ravel_1 = right_term[:, :, 1].ravel("C")
            # e_ravel = np.hstack((e_ravel_0, e_ravel_1))
            # C1 = 1 + (self.lam / (2 * self.eps * dk))
            # C2 = 2 * self.lam * self.eps / dk
            # hat = 2 * self.beta / dk* self.optD(self.un_SLPAM) ** 2
            # hat0 = hat[:, :, 0].ravel("C")
            # hat1 = hat[:, :, 1].ravel("C")
            # hat_concatenate = np.hstack((hat0, hat1))
            # block1 = csc_matrix(diags([hat_concatenate.tolist()], [0]))
            # block2 = csc_matrix(identity(self.rows*self.cols * 2) * C1)
            # block3 = C2 * csc_matrix(self.optD1().T.dot(self.optD1()))
            # mat = block1 + block2 + block3
            # # temp,info = lgmres(mat,e_ravel, tol=1e-7)
            # temp = spsolve(mat,e_ravel)

            # A = LinearOperator((self.rows*self.cols*2,self.rows*self.cols*2), matvec=self.mv)
            # # time_start = time.time()
            # temp,info = lgmres(A,e_ravel, tol=1e-5)
            # # print('linear op--',time.time()-time_start)
            e[:, :, 0] = temp[: self.rows*self.cols].reshape(self.rows, self.cols)
            e[:, :, 1] = temp[self.rows*self.cols:].reshape( self.rows, self.cols)
            return e
        elif self.norm_type == "AT" and (self.method=='PALM' or self.method =='PALM_AT_eps_descent'):
            # tau is lambda/dk
            time_start = time.time()

            C1 = 1 + (tau / (2 * self.eps))
            C2 = 2 * tau * self.eps

            F = 1 / (C2 * np.conj(self.v) * self.v + C1)
            G = F * C2 * np.conj(self.v) * self.h
            J = C2 * np.conj(self.h) * self.h + C1
            K = C2 * np.conj(self.h) * self.v * G
            L = C2 * np.conj(self.h) * self.v
            e[:, :, 0] = np.real(fftpack.ifft2((F + G / (J - K) * L) * fftpack.fft2(e[:, :, 0], axes=(0, 1))+ G / (J - K) * fftpack.fft2(e[:, :, 1], axes=(0, 1)),axes=(0, 1),))
            e[:, :, 1] = np.real(fftpack.ifft2(1 / (J - K) * L * fftpack.fft2(e[:, :, 0], axes=(0, 1))+ 1 / (J - K) * fftpack.fft2(e[:, :, 1], axes=(0, 1)),axes=(0, 1),))
            return e
        elif self.norm_type == "l1l2":
            return self.prox.L1L2(e, self.gamma_1, self.gamma_2, tau)


        # Difference operator D
    def optD(self, x):

        if self.canal == 3:
            y = np.zeros((self.rows, self.cols, 2, self.canal))
            y[:, :, 0, :] = (np.concatenate((x[:, 1:, :] - x[:, 0:-1, :], np.zeros((self.rows, 1, self.canal))),axis=1,)/ 2.0 )
            y[:, :, 1, :] = (np.concatenate( (x[1:, :, :] - x[0:-1, :, :], np.zeros((1, self.cols, self.canal))),axis=0,)/ 2.0)
            return y

        elif self.canal == 1:
            y = np.zeros((self.rows, self.cols, 2))
            # # print(temp.shape)
            y[:, :, 0] = (np.concatenate((x[:, 1:] - x[:, 0:-1], np.zeros((self.rows, 1))), axis=1)/ 2.0)
            y[:, :, 1] = (np.concatenate((x[1:, :] - x[0:-1, :], np.zeros((1, self.cols))), axis=0 )/ 2.0)
            return y

    def optDadjoint(self, x):
        if self.canal == 3:
            y1 = (np.concatenate((x[:, 0, 0, :].reshape(self.rows, 1, 3),x[:, 1:-1, 0, :] - x[:, 0:-2, 0, :],-x[:, -2, 0, :].reshape(self.rows, 1, 3),),axis=1,)/ 2) 
            y2 = (np.concatenate((x[0, :, 1, :].reshape(1, self.cols, 3),x[1:-1, :, 1, :] - x[:-2, :, 1, :],-x[-2, :, 1, :].reshape(1, self.cols, 3),),axis=0,)/ 2)
            y = -y1 - y2
            return y
        elif self.canal == 1:
            y1 = (np.concatenate((x[:, 0, 0].reshape(self.rows, 1), x[:, 1:-1, 0] - x[:, 0:-2, 0],-x[:, -2, 0].reshape(self.rows, 1),),axis=1,)/ 2.0)
            y2 = ( np.concatenate(( x[0, :, 1].reshape(1, self.cols),x[1:-1, :, 1] - x[:-2, :, 1],-x[-2, :, 1].reshape(1, self.cols),),axis=0,)/ 2.0)
            y = -y1 - y2
            return y

    def L_nabla_f(self):
        xn = np.random.rand(*self.image.shape)
        rhon = 1 + 1e-2
        rhok = 1
        k = 0
        xn1 = xn
        while abs(rhok - rhon) / abs(rhok) >= 1e-5:
            xn = xn1 / np.linalg.norm(xn1, "fro")
            xn1 = 2 * self.Dadjoint(self.optD(xn))
            rhon = rhok
            k += 1
            rhok = np.linalg.norm(xn1, "fro")
        return 1.01 * np.sqrt(rhok) + 1e-10

    def opt_H(self):
        diagonals = [
            (0.5 * np.ones(self.cols - 1)).tolist(),
            (-0.5 * np.ones(self.cols)).tolist(),
            [0.5],
        ]
        block = diags(diagonals, [1, 0, -self.cols + 1])
        opt_H = scp.sparse.block_diag([block for _ in range(self.rows)])
        return opt_H

    def opt_V(self):
        diagonals = [
            -0.5 * np.ones(self.rows * self.cols),
            0.5 * np.ones((self.rows - 1) * self.cols),
            0.5 * np.ones(self.cols),
        ]
        opt_V = diags(diagonals, [0, self.cols, -(self.rows * self.cols) + self.cols])
        return opt_V

    def optD1(self):
        D1 = hstack((self.opt_V(), -self.opt_H()))
        return D1


    # def optD(self, x):
    #     if self.canal == 3:
    #         y = np.zeros((self.rows, self.cols, 2, self.canal))
    #         y[:, :, 0, :] = np.concatenate((x[1:, :, :] - x[0:-1, :, :], np.zeros((1, self.cols, self.canal))), axis=0,)/ 2.0
    #         y[:, :, 1, :] =  np.concatenate((x[:, 1:, :] - x[:, 0:-1, :], np.zeros((self.rows, 1, self.canal))),axis=1,)/ 2.0
    #         return y
    #     elif self.canal == 1:
    #         y = np.zeros((self.rows, self.cols, 2))
    #         y[:, :, 0] = (np.concatenate((x[1:, :] - x[0:-1, :], np.zeros((1, self.cols))), axis=0)/ 2.0)
    #         y[:, :, 1] = (np.concatenate((x[:, 1:] - x[:, 0:-1], np.zeros((self.rows, 1))), axis=1)/ 2.0)
    #         return y

    # def optDadjoint(self, x):
    #     if self.canal == 3:
    #         y1 = (np.concatenate((x[0, :, 0, :].reshape(1, self.cols, 3),- x[0:-2, :, 0, :]+x[1:-1, :, 0, :] ,-x[-2, :, 0, :].reshape(1, self.cols, 3),),axis=0,)/ 2)            
    #         y2 = (np.concatenate((x[:, 0, 1, :].reshape(self.rows, 1, 3),- x[:, 0:-2, 1, :]+x[:, 1:-1, 1, :] ,-x[:, -2, 1, :].reshape(self.rows, 1, 3),),axis=1,)/ 2)
    #         y = -y1 - y2
    #         return y
    #     elif self.canal == 1:
    #         rows,cols,_ = x.shape
    #         y1 = np.concatenate((x[0, :, 0].reshape(1, cols),-x[0:-2, :, 0] + x[1:-1, :, 0],-x[-2, :, 0].reshape(1, cols),),axis=0,)/ 2.0
    #         y2 = np.concatenate((x[:, 0, 1].reshape(rows, 1),-x[:, 0:-2, 1] + x[:, 1:-1, 1],-x[:, -2, 1].reshape(rows, 1),),axis=1)/ 2.0
    #         y = -y1 - y2
    #         return y    

    # def optDV(self):
    #     diagonals = [
    #         (0.5 * np.ones(self.cols - 1)).tolist(),
    #         (-0.5 * np.ones(self.cols)).tolist(),
    #         [0.5],
    #     ]
    #     block = diags(diagonals, [1, 0, -self.cols + 1])
    #     opt_V = scp.sparse.block_diag([block for _ in range(self.rows)])
    #     return opt_V

    # def optDH(self):
    #     diagonals = [
    #         -0.5 * np.ones(self.rows * self.cols),
    #         0.5 * np.ones((self.rows - 1) * self.cols),
    #         0.5 * np.ones(self.cols),
    #     ]
    #     opt_H = diags(diagonals, [0, self.cols, -(self.rows * self.cols) + self.cols])

    #     return opt_H

    # def optD1(self):
    #     D1 = hstack((self.optDV(), -self.optDH()))
    #     return D1

    # def optD0(self):
    #     D = vstack((self.optDH(), self.optDV()))
    #     return D


    def L_nabla_f(self):
        xn = np.random.rand(*self.image.shape)
        rhon = 1 + 1e-2
        rhok = 1
        k = 0
        xn1 = xn
        while abs(rhok - rhon) / abs(rhok) >= 1e-5:
            xn = xn1 / np.linalg.norm(xn1, "fro")
            xn1 = 2 * self.Dadjoint(self.optD(xn))
            rhon = rhok
            k += 1
            rhok = np.linalg.norm(xn1, "fro")
        return 1.01 * np.sqrt(rhok) + 1e-10

    def norm_ck_dk_opt(self, method, e):
        iter = 0
        if method == "SL-PAM":
            #             xn = np.random.rand(*self.image.shape)
            #             rhon = 1+1e-2
            #             rhok = 1
            #             k=0
            #             xn1 = xn
            # while abs(rhok - rhon)/abs(rhok) >= 1e-5 and iter<5000:
            #     xn = xn1/np.linalg.norm(xn1,'fro')
            #     xn1 = self.S_du(xn,e)
            #     rhon = rhok
            #     k+=1
            #     rhok = np.linalg.norm(xn1,'fro')
            #     iter+=1
            rhok = 4
            return 1.01 * self.beta * np.sqrt(rhok) + 1e-8
        if method == "PALM":
            #             xn = np.random.rand(*self.image.shape)
            #             rhon = 1 +1e-2
            #             rhok_u = 1
            #             rhok_e = 1
            #             k = 0
            #             xn1 = xn
            # while abs(rhok_u - rhon) / abs(rhok_u) >= 1e-5 and iter<5000:
            #     xn = xn1 / np.linalg.norm(xn1, 'fro')
            #     xn1 = self.S_du(xn, e)
            #     rhon = rhok_u
            #     k += 1
            #     rhok_u = np.linalg.norm(xn1, 'fro')
            #     iter+=1
            rhok_u = 4

            # xn = np.random.rand(*self.en_PALM.shape)
            # xn = np.ones_like(self.en_PALM)
            # xn1 = xn
            iter = 0
            #             while abs(rhok_e - rhon) / abs(rhok_e) >= 1e-5:# and iter<5000:
            #                 xn[:,:,0] = xn1[:,:,0] / (np.linalg.norm(xn1[:,:,0], 'fro')+1e-10)
            #                 xn[:, :,1] = xn1[:, :, 1] / (np.linalg.norm(xn1[:, :, 1], 'fro')+1e-10)
            #                 xn1 = -2*(1-xn)*self.S_D(self.un_PALM)
            #                 rhon = rhok_e
            #                 k += 1
            # temp1 = np.linalg.norm(xn1[:,:,0], 'fro')
            # temp2 = np.linalg.norm(xn1[:, :, 1], 'fro')
            # rhok_e= np.sqrt(temp1**2+temp2**2)
            #                 rhok_e= np.sqrt(np.sum(xn1**2))
            # iter+=!
            rhok_e = 4

            return (
                1.01 * 2 * self.beta * np.sqrt(rhok_u) + 1e-8,
                1.01 * 2 * self.beta * np.sqrt(rhok_e) + 1e-8,
            )


    def loop_SL_PAM(self):
        self.Jn_SLPAM = []
        self.psnrlist= []
        err = 1.0     
        it = 0

        x=np.random.normal(0,1,self.noised_image_input.shape)
        y=np.random.normal(0,1,self.en_SLPAM.shape)
        self.Jn_SLPAM += [self.data_fidelity(self.un_SLPAM, self.noised_image_input)+self.coupling_term(self.un_SLPAM, self.en_SLPAM)+ self.lam * self.R_term(self.en_SLPAM)]
        
        # Main loop
        with alive_bar(self.MaximumIteration) as bar:
            while (err > self.stop_criterion) and (it < self.MaximumIteration):
                # if self.optD_type == "OptD":
                #     ck = self.norm_ck_dk_opt(method="SL-PAM", e=self.en_SLPAM)
                self.psnrlist+= [PSNR(self.un_SLPAM,self.clean)]
                normDsq = 2.
                ck = 1.01*self.beta*normDsq+ 1e-8
                self.dk = self.dkSLPAM_factor*ck
                self.un_SLPAM = self.data_fidelity_prox(self.un_SLPAM- (1/ck) * self.coupling_term_du(self.un_SLPAM, self.en_SLPAM),1 / ck,self.noised_image_input)

                if self.norm_type == "l1":
                    over = self.beta * self.S_D(self.un_SLPAM)+ self.dk/ 2.0 * self.en_SLPAM
                    lower = self.beta * self.S_D(self.un_SLPAM) + self.dk / 2.0
                    self.en_SLPAM = self.R_prox(over / lower, self.lam / (2 * lower))
                elif self.norm_type == "AT":
                    self.en_SLPAM = self.R_prox(self.en_SLPAM,ck=ck,dk=self.dk)

                self.Jn_SLPAM+= [self.data_fidelity(self.un_SLPAM, self.noised_image_input)+self.coupling_term(self.un_SLPAM, self.en_SLPAM)+ self.lam * self.R_term(self.en_SLPAM)]
                
                err = abs(self.Jn_SLPAM[it + 1] - self.Jn_SLPAM[it]) / abs(self.Jn_SLPAM[it])
                bar()
                it += 1
                
            self.contour_map = self.en_SLPAM
            return self.en_SLPAM,self.un_SLPAM,self.Jn_SLPAM, self.psnrlist

    def loop_PALM(self):
        self.Jn_PALM = []
        self.psnrlist= []
        it = 0
        err = 1.0
        self.Jn_PALM +=  [self.data_fidelity(self.un_PALM, self.noised_image_input)+self.coupling_term(self.un_PALM, self.en_PALM)+ self.lam * self.R_term(self.en_PALM)]
        with alive_bar(self.MaximumIteration) as bar:
            while (err > self.stop_criterion) and (it < self.MaximumIteration):
                self.psnrlist+= [PSNR(self.un_PALM,self.clean)]
                normDsq = 2.
                ck = 1.01*self.beta*normDsq+ 1e-8
                dk = 1.01*self.beta*normDsq+ 1e-8
                self.un_PALM = self.data_fidelity_prox(self.un_PALM - (1/ck)* self.coupling_term_du(self.un_PALM, self.en_PALM),1 / ck, self.noised_image_input)
                self.en_PALM = self.R_prox(self.en_PALM - (1/ dk) * self.coupling_term_de(self.un_PALM, self.en_PALM),self.lam / dk)

                self.Jn_PALM += [self.data_fidelity(self.un_PALM, self.noised_image_input)+self.coupling_term(self.un_PALM, self.en_PALM)+ self.lam * self.R_term(self.en_PALM)]
                
                err = abs(self.Jn_PALM[it + 1] - self.Jn_PALM[it]) / abs(self.Jn_PALM[it])
                bar()
                it += 1
        return  self.en_PALM,self.un_PALM,self.Jn_PALM,self.psnrlist

    def loop_SLPAM_AT_eps_descent(self):
        self.Jn_SLPAM = []
        self.psnrlist= []
        self.un_list = []
        self.en_list = []
        it = 0
        err = 1.0
        self.Jn_SLPAM +=  [self.data_fidelity(self.un_SLPAM, self.noised_image_input)+self.coupling_term(self.un_SLPAM, self.en_SLPAM)+ self.lam * self.R_term(self.en_SLPAM)]
        descent_factor= 1.5
        descent_times = int(np.ceil(math.log(self.eps/self.eps_AT_min,descent_factor)))
        def edges_to_pix_contour(cont_edges):
            pix = cont_edges[:,:,0]+cont_edges[:,:,1]
            return np.clip(pix,0,1)
        with alive_bar(self.MaximumIteration*descent_times) as bar:
            while self.eps >= self.eps_AT_min:
                print("Epsilon here: ", self.eps)
                err = 10
                while (err > self.stop_criterion) and (it < self.MaximumIteration): 
                    self.psnrlist+= [PSNR(self.un_SLPAM,self.clean)]
                    normDsq = 2.
                    ck = 1.01*self.beta*normDsq+ 1e-8
                    self.dk = 1e-4#self.dkSLPAM_factor*ck
                    self.un_SLPAM = self.data_fidelity_prox(self.un_SLPAM - (1/ck)* self.coupling_term_du(self.un_SLPAM, self.en_PALM),1 / ck, self.noised_image_input)
                    self.en_SLPAM = self.R_prox(self.en_SLPAM,ck=ck,dk=self.dk)

                    self.Jn_SLPAM += [self.data_fidelity(self.un_SLPAM, self.noised_image_input)+self.coupling_term(self.un_SLPAM, self.en_SLPAM)+ self.lam * self.R_term(self.en_SLPAM)]
                    
                    err = abs(self.Jn_SLPAM[it + 1] - self.Jn_SLPAM[it]) / abs(self.Jn_SLPAM[it])
                    bar()
                    it += 1
                self.un_list+= [self.un_SLPAM]
                self.en_list+= [self.en_SLPAM]
                self.eps = self.eps / descent_factor
                # self.beta = self.beta / np.e
                # self.lam = self.lam * np.e
                it=0
                err=10
                un_SLPAM_fin_loop = self.noised_image_input#self.un_SLPAM
        return  self.en_SLPAM,self.un_SLPAM,self.Jn_SLPAM,self.un_list,self.en_list,self.psnrlist

    def loop_PALM_AT_eps_descent(self):
        self.Jn_PALM = []
        self.psnrlist= []
        self.un_list = []
        self.en_list = []
        it = 0
        err = 1.0
        self.Jn_PALM +=  [self.data_fidelity(self.un_PALM, self.noised_image_input)+self.coupling_term(self.un_PALM, self.en_PALM)+ self.lam * self.R_term(self.en_PALM)]
        un_PALM_fin_loop = self.noised_image_input
        descent_factor= 1.5
        descent_times = int(np.ceil(math.log(self.eps/self.eps_AT_min,descent_factor)))
        def edges_to_pix_contour(cont_edges):
            pix = cont_edges[:,:,0]+cont_edges[:,:,1]
            return np.clip(pix,0,1)
        with alive_bar(self.MaximumIteration*descent_times) as bar:
            while self.eps >= self.eps_AT_min:
                print("Epsilon: ", self.eps)
                err = 10
                while (err > self.stop_criterion) and (it < self.MaximumIteration): 
                    # if self.optD_type == "Matrix":
                    #     ck, dk = self.norm_ck_dk(method="PALM")
                    self.psnrlist+= [PSNR(self.un_PALM,self.clean)]
                    normDsq = 2.
                    ck = 1.01*self.beta*normDsq+ 1e-8
                    dk = 1.01*self.beta*normDsq+ 1e-8
                    self.un_PALM = self.data_fidelity_prox(self.un_PALM - (1/ck)* self.coupling_term_du(self.un_PALM, self.en_PALM),1 / ck, un_PALM_fin_loop)
                    self.en_PALM = self.R_prox(self.en_PALM - (1/ dk) * self.coupling_term_de(self.un_PALM, self.en_PALM),self.lam / dk)

                    self.Jn_PALM += [self.data_fidelity(self.un_PALM, un_PALM_fin_loop)+self.coupling_term(self.un_PALM, self.en_PALM)+ self.lam * self.R_term(self.en_PALM)]
                    
                    err = abs(self.Jn_PALM[it + 1] - self.Jn_PALM[it]) / abs(self.Jn_PALM[it])
                    bar()
                    it += 1
                self.un_list+= [self.un_PALM]
                self.en_list+= [self.en_PALM]
                self.eps = self.eps /descent_factor#np.e
                # self.beta = self.beta / np.e
                it=0
                err=10
                un_PALM_fin_loop = self.noised_image_input
        #         plt.figure()
        #         plt.subplot(321)
        #         plt.imshow(self.un_PALM)
        #         plt.subplot(323)
        #         plt.imshow(edges_to_pix_contour(self.en_PALM),'gray')
        #         plt.legend()
        # plt.show()
        return  self.en_PALM,self.un_PALM,self.Jn_PALM,self.un_list,self.en_list,self.psnrlist

    def process(self):
        if self.method == "SLPAM":
            self.en_SLPAM,self.un_SLPAM,self.Jn_SLPAM,self.psnrlist= self.loop_SL_PAM()
            return self.en_SLPAM,self.un_SLPAM,self.Jn_SLPAM,self.psnrlist
        elif self.method == "PALM":
            self.en_PALM,self.un_PALM,self.Jn_PALM,self.psnrlist= self.loop_PALM()
            return self.en_PALM,self.un_PALM,self.Jn_PALM,self.psnrlist
        elif self.method == "PALM_AT_eps_descent":
            self.norm_type='AT'
            self.en_PALM,self.un_PALM,self.Jn_PALM,self.un_list,self.en_list,self.psnrlist= self.loop_PALM_AT_eps_descent()
            return self.en_PALM,self.un_PALM,self.Jn_PALM,self.un_list,self.en_list,self.psnrlist
        elif self.method == "SLPAM_AT_eps_descent":
            self.norm_type='AT'
            self.en_SLPAM,self.un_SLPAM,self.Jn_SLPAM,self.un_list,self.en_list,self.psnrlist= self.loop_SLPAM_AT_eps_descent()
            return self.en_SLPAM,self.un_SLPAM,self.Jn_SLPAM,self.un_list,self.en_list,self.psnrlist



