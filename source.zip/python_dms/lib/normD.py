import numpy as np


def optD(x):
    rows,cols = x.shape
    y=  np.zeros((rows,cols,2))
    y[:, :, 0] = np.concatenate((x[:, 1:] - x[:, 0:-1], np.zeros((rows, 1))),axis=1) / 2.
    y[:, :, 1] = np.concatenate((x[1:, :] - x[0:-1, :], np.zeros((1, cols))),axis=0) / 2.
    return y

def optDadjoint(x):
    rows,cols,channel = x.shape
    y1 = (np.concatenate((x[:, 0, 0].reshape(rows, 1),x[:, 1:-1, 0] - x[:, 0:-2, 0],-x[:, -1, 0].reshape(rows, 1),),axis=1,)/ 2.0)
    y2 = ( np.concatenate( (x[0, :, 1].reshape(1, cols),x[1:-1, :, 1] - x[:-2, :, 1], -x[-1, :, 1].reshape(1, cols),),axis=0,)/ 2.0)
    y = -y1 - y2
    return y


def PowerIteration():
    xn = np.random.normal(0,1,size=(200,200))
    xn1 = xn
    N = 1000
    rhon = 1+1e-6
    rhonl = np.zeros(N)
    rhonl[0] = 1
    for i in range(N-1):
        xn = xn1/np.linalg.norm(xn1)
        xn1 = optDadjoint(optD(xn))
        rhon = rhonl[i]
        rhonl[i+1] = np.linalg.norm(xn1)
    print(rhonl)

PowerIteration()